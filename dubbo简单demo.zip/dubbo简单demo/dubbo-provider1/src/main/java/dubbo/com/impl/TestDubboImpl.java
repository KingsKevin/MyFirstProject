package dubbo.com.impl;

import org.springframework.stereotype.Service;

import dubbo.com.api.TestDubboApi;

@Service(value="TestDubbo")
public class TestDubboImpl implements TestDubboApi {

	public String sayHello(String name) {
		
		return name+"say hello";
	}

}
