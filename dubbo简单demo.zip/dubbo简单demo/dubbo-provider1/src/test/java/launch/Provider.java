package launch;

public class Provider {
	public static void main(String[] args) {
		
		com.alibaba.dubbo.container.Main.main(args);
	}

}
