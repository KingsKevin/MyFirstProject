package com.dubbo.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import dubbo.com.api.TestDubboApi;

@Controller
@RequestMapping(value="dubbo")
public class DubboTestController {

	 @Autowired(required=false)
	  private TestDubboApi dubboApi;
	
	@RequestMapping(value="first",method = RequestMethod.GET)
	public void dubboTest(HttpServletRequest request,HttpServletResponse response){
		
		String Str = dubboApi.sayHello("小K ");
		
		PrintWriter out = null;
		try {
			out = response.getWriter();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		out.print(Str);
		out.flush();
		out.close();
	}
		
	
}
