package dubbo.com.api;

public interface TestDubboApi {
	
	public String sayHello(String name);

}
